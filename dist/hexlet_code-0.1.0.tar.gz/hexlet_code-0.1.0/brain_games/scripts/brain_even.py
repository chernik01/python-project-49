#!/usr/bin/env python3
import prompt
import random


def is_even():
    name = prompt.string('May I have your name? ')
    print(f"Hello, {name}!") 
    print('Answer "yes" if the number is even, otherwise answer "no".')
    flag = True
    i = 1
    while i <= 3:
        number = random.randint(1,100)
        print('Question:', number)
        user_input = prompt.string('Your answer: ')
        if number % 2 == 0 and user_input == 'yes':
            print('Correct!')
            i += 1
        elif number % 2 != 0 and user_input == 'no':
            print('Correct!')
            i += 1
        else:
            if number % 2 == 0:
                right_user_input = 'yes'
            else:
                right_user_input = 'no'
            print(f"'{user_input}'is wrong answer;(.Correct answer was '{right_user_input}'\nLet's try again, {name}!")
            flag = False
            break
    if flag == True:
        print(f"Congratulations, {name}!")
    

def main():
    print('Welcome to the Brain Games!')
    is_even()
    

if __name__ == '__main__':
    main()
  