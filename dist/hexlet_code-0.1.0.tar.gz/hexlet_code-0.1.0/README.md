### Hexlet tests and linter status:
[![Actions Status](https://github.com/chernik01/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/chernik01/python-project-49/actions)

### Link to brain-even game
https://asciinema.org/a/qrROnJqinaczWPTZVrXHHgfRp

### Link to brain-calc game
https://asciinema.org/a/YaraS4v3AlRaZQihPTrcAN6rY

### Link to brain-gcd game
https://asciinema.org/a/2CroF5DdfqqFeAPm1xmZJI4az

