### Hexlet tests and linter status:
[![Actions Status](https://github.com/chernik01/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/chernik01/python-project-49/actions)

### Link to brain-even game
https://asciinema.org/a/qrROnJqinaczWPTZVrXHHgfRp

